require 'test_helper'

class TurnsHelperTest < ActionView::TestCase
end
