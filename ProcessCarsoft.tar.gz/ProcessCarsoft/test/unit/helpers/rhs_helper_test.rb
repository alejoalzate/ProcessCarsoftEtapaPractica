require 'test_helper'

class RhsHelperTest < ActionView::TestCase
end
