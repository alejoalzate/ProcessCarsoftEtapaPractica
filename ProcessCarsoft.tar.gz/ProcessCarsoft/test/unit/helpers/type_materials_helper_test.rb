require 'test_helper'

class TypeMaterialsHelperTest < ActionView::TestCase
end
