require 'test_helper'

class SuggestionsHelperTest < ActionView::TestCase
end
