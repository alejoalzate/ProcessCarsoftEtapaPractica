require 'test_helper'

class TypeUsersHelperTest < ActionView::TestCase
end
