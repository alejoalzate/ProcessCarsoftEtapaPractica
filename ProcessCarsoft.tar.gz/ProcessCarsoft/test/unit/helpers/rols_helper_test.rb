require 'test_helper'

class RolsHelperTest < ActionView::TestCase
end
