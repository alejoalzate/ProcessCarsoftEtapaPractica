require 'test_helper'

class RhTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
