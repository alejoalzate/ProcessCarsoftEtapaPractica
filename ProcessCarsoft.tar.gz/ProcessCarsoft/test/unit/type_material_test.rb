require 'test_helper'

class TypeMaterialTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
