require 'test_helper'

class TypeUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
