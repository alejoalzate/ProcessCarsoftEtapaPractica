$(document).ready(function() {
 
     $('.datepicker').datepicker({
        "format": "yyyy-mm-dd",
        "weekStart": 1,
        "language": 'es',
        "autoclose": true
      })

});